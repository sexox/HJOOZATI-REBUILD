package com.hjoozati.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF090713)
private val Panel = Color(0xFF191329)
private val Purple = Color(0xFF8C54FF)
private val Gold = Color(0xFFE8BD69)
private val Muted = Color(0xFFB7AEC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = HDatabase.get(this)
        setContent { HTheme { HJoozatiApp(db) } }
    }
}

@Composable
private fun HTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Gold, background = Ink, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    ), content = content)
}

@Entity(tableName = "bookings", indices = [Index(value = ["startAt"], unique = false)])
data class Booking(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customer: String,
    val phone: String = "",
    val activity: String = "حجز ملعب",
    val startAt: Long,
    val durationMinutes: Int = 60,
    val price: Double = 0.0,
    val paid: Double = 0.0,
    val status: String = "مؤكد",
    val note: String = ""
)

@Entity(tableName = "customers")
data class Customer(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val phone: String = "", val notes: String = "")

@Entity(tableName = "expenses")
data class Expense(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val amount: Double, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "matches")
data class MatchRecord(@PrimaryKey(autoGenerate = true) val id: Long = 0, val tournament: String, val teamA: String, val teamB: String, val scoreA: Int = 0, val scoreB: Int = 0, val playedAt: Long = System.currentTimeMillis())

@Dao interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY startAt ASC") fun observeAll(): Flow<List<Booking>>
    @Insert suspend fun insert(item: Booking): Long
    @Update suspend fun update(item: Booking)
    @Delete suspend fun delete(item: Booking)
    @Query("SELECT COUNT(*) FROM bookings WHERE status != 'ملغي' AND startAt < :endAt AND (startAt + durationMinutes * 60000) > :startAt")
    suspend fun conflicts(startAt: Long, endAt: Long): Int
}
@Dao interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name") fun observeAll(): Flow<List<Customer>>
    @Insert suspend fun insert(item: Customer)
    @Update suspend fun update(item: Customer)
    @Delete suspend fun delete(item: Customer)
}
@Dao interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC") fun observeAll(): Flow<List<Expense>>
    @Insert suspend fun insert(item: Expense)
}
@Dao interface MatchDao {
    @Query("SELECT * FROM matches ORDER BY playedAt DESC") fun observeAll(): Flow<List<MatchRecord>>
    @Insert suspend fun insert(item: MatchRecord)
    @Update suspend fun update(item: MatchRecord)
}
@Database(entities = [Booking::class, Customer::class, Expense::class, MatchRecord::class], version = 1, exportSchema = true)
abstract class HDatabase : RoomDatabase() {
    abstract fun bookings(): BookingDao
    abstract fun customers(): CustomerDao
    abstract fun expenses(): ExpenseDao
    abstract fun matches(): MatchDao
    companion object {
        @Volatile private var INSTANCE: HDatabase? = null
        fun get(context: android.content.Context): HDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, HDatabase::class.java, "hjoozati.db").build().also { INSTANCE = it }
        }
    }
}

@Composable
private fun HJoozatiApp(db: HDatabase) {
    var tab by remember { mutableStateOf("الرئيسية") }
    val tabs = listOf("الرئيسية", "الحجوزات", "العملاء", "المالية", "البطولات")
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel) {
            val icons = listOf(Icons.Default.Dashboard, Icons.Default.CalendarMonth, Icons.Default.People, Icons.Default.AccountBalanceWallet, Icons.Default.EmojiEvents)
            tabs.forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) })
            }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).background(Brush.verticalGradient(listOf(Ink, Color(0xFF17102B))))) {
            Header()
            when (tab) {
                "الرئيسية" -> Dashboard(db)
                "الحجوزات" -> BookingsScreen(db)
                "العملاء" -> CustomersScreen(db)
                "المالية" -> FinanceScreen(db)
                else -> TournamentScreen(db)
            }
        }
    }
}

@Composable private fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("HJOOZATI", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("إدارة ذكية • تجربة احترافية", color = Muted, fontSize = 11.sp)
        }
        Surface(shape = RoundedCornerShape(16.dp), color = Purple.copy(alpha = .2f), border = BorderStroke(1.dp, Purple.copy(alpha = .5f))) {
            Icon(Icons.Default.AccountCircle, null, tint = Gold, modifier = Modifier.padding(10.dp))
        }
    }
}
@Composable private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier, shape = RoundedCornerShape(22.dp), color = Color.White.copy(alpha = .055f), border = BorderStroke(1.dp, Color.White.copy(alpha = .12f)), shadowElevation = 8.dp) {
        Column(Modifier.padding(16.dp), content = content)
    }
}
@Composable private fun Dashboard(db: HDatabase) {
    val bookings by db.bookings().observeAll().collectAsState(initial = emptyList())
    val expenses by db.expenses().observeAll().collectAsState(initial = emptyList())
    val today = bookings.filter { Date(it.startAt).date == Date().date }
    val revenue = bookings.sumOf { it.paid }
    val cost = expenses.sumOf { it.amount }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("مساحة عملك", color = Muted)
                Text("كل حجوزاتك تحت السيطرة", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("نظرة سريعة على نشاطك اليومي", color = Gold, fontSize = 12.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Metric("حجوزات اليوم", today.size.toString(), Icons.Default.EventAvailable, Modifier.weight(1f))
                Metric("إجمالي المقبوض", money(revenue), Icons.Default.Payments, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Metric("المصروفات", money(cost), Icons.Default.ReceiptLong, Modifier.weight(1f))
                Metric("صافي الحركة", money(revenue-cost), Icons.Default.TrendingUp, Modifier.weight(1f))
            }
        }
        item { Text("الحجوزات القادمة", color = Gold, fontWeight = FontWeight.Bold) }
        items(bookings.filter { it.startAt >= System.currentTimeMillis() }.take(5)) { BookingRow(it) }
        item { Text("مساعد HJOOZATI", color = Gold, fontWeight = FontWeight.Bold) }
        item { GlassCard(Modifier.fillMaxWidth()) { Text(if (today.isEmpty()) "لا توجد حجوزات اليوم. يمكنك إضافة حجز جديد من تبويب الحجوزات." else "لديك ${today.size} حجوزات اليوم. راجع الأوقات لتجنب التداخل.", color = Color.White) } }
    }
}
@Composable private fun Metric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    GlassCard(modifier) { Icon(icon, null, tint = Gold); Spacer(Modifier.height(8.dp)); Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 11.sp) }
}
private fun money(v: Double) = String.format(Locale.US, "%,.0f د.ع", v)

@Composable private fun BookingsScreen(db: HDatabase) {
    val list by db.bookings().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(false) }
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("0") }
    var paid by remember { mutableStateOf("0") }
    var dateText by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("إدارة الحجوزات", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Button(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text("حجز جديد") } }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(list) { BookingRow(it, onDelete = { scope.launch { db.bookings().delete(it) } }) } }
    }
    if (show) AlertDialog(onDismissRequest = { show = false }, title = { Text("إضافة حجز") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(customer, { customer = it }, label = { Text("اسم العميل") }, singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, singleLine = true)
            OutlinedTextField(dateText, { dateText = it }, label = { Text("التاريخ والوقت: 2026-11-12 17:00") }, singleLine = true)
            OutlinedTextField(price, { price = it }, label = { Text("السعر بالدينار") }, singleLine = true)
            OutlinedTextField(paid, { paid = it }, label = { Text("المدفوع") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = {
        val parsed = try { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(dateText)?.time } catch (_: Exception) { null }
        if (customer.isNotBlank() && parsed != null) scope.launch {
            val item = Booking(customer = customer.trim(), phone = phone.trim(), startAt = parsed, price = price.toDoubleOrNull() ?: 0.0, paid = paid.toDoubleOrNull() ?: 0.0)
            val end = parsed + item.durationMinutes * 60000L
            if (db.bookings().conflicts(parsed, end) == 0) db.bookings().insert(item)
            show = false; customer = ""; phone = ""; dateText = ""; price = "0"; paid = "0"
        }
    }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } })
}
@Composable private fun BookingRow(item: Booking, onDelete: (() -> Unit)? = null) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.customer, fontWeight = FontWeight.Bold)
                Text(SimpleDateFormat("yyyy/MM/dd • HH:mm", Locale.getDefault()).format(Date(item.startAt)), color = Muted, fontSize = 12.sp)
                Text("${item.activity}  •  ${money(item.price)}  •  مدفوع ${money(item.paid)}", color = Gold, fontSize = 11.sp)
            }
            if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFFF7777)) }
        }
    }
}
@Composable private fun CustomersScreen(db: HDatabase) {
    val list by db.customers().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("العملاء وسجلهم", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), label = { Text("اسم العميل") }, singleLine = true)
            IconButton(onClick = { if (name.isNotBlank()) scope.launch { db.customers().insert(Customer(name=name.trim(), phone=phone)); name=""; phone="" } }) { Icon(Icons.Default.AddCircle, null, tint = Gold) }
        }
        OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text("رقم الهاتف (اختياري)") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(list) { GlassCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Text(it.name, fontWeight = FontWeight.Bold); Text(it.phone, color = Muted) } } }
    }
}
@Composable private fun FinanceScreen(db: HDatabase) {
    val expenses by db.expenses().observeAll().collectAsState(initial = emptyList())
    val bookings by db.bookings().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("المالية والتقارير", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        GlassCard(Modifier.fillMaxWidth()) { Text("المقبوضات", color = Muted); Text(money(bookings.sumOf { it.paid }), color = Gold, fontSize = 22.sp); Text("المصروفات", color = Muted); Text(money(expenses.sumOf { it.amount }), fontSize = 22.sp); Text("الصافي", color = Muted); Text(money(bookings.sumOf { it.paid } - expenses.sumOf { it.amount }), color = Gold, fontSize = 22.sp) }
        Spacer(Modifier.height(14.dp))
        Text("إضافة مصروف", color = Gold, fontWeight = FontWeight.Bold)
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("وصف المصروف") })
        OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text("المبلغ") })
        Button(onClick = { val n = amount.toDoubleOrNull(); if (title.isNotBlank() && n != null) scope.launch { db.expenses().insert(Expense(title=title, amount=n)); title=""; amount="" } }, modifier = Modifier.fillMaxWidth()) { Text("حفظ المصروف") }
        Spacer(Modifier.height(10.dp))
        LazyColumn { items(expenses) { Text("${it.title} — ${money(it.amount)}", Modifier.fillMaxWidth().padding(10.dp), color = Color.White) } }
    }
}
@Composable private fun TournamentScreen(db: HDatabase) {
    val matches by db.matches().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var tournament by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }; var b by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("البطولات والمباريات", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(tournament, { tournament = it }, Modifier.fillMaxWidth(), label = { Text("اسم البطولة") })
        OutlinedTextField(a, { a = it }, Modifier.fillMaxWidth(), label = { Text("الفريق الأول") })
        OutlinedTextField(b, { b = it }, Modifier.fillMaxWidth(), label = { Text("الفريق الثاني") })
        Button(onClick = { if (tournament.isNotBlank() && a.isNotBlank() && b.isNotBlank()) scope.launch { db.matches().insert(MatchRecord(tournament=tournament, teamA=a, teamB=b)); a=""; b="" } }, modifier = Modifier.fillMaxWidth()) { Text("إضافة مباراة") }
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(matches) { GlassCard(Modifier.fillMaxWidth().padding(bottom=8.dp)) { Text(it.tournament, color=Gold); Text("${it.teamA}  ${it.scoreA} : ${it.scoreB}  ${it.teamB}", fontWeight=FontWeight.Bold) } } }
    }
}
